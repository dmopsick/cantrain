
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dmopsick',
  applicationName: 'cantrain-api',
  appUid: 'cnx4RFPTKc2XdLwPYs',
  orgUid: 'c0fa4187-23cf-4e2a-b33e-bb73713d774e',
  deploymentUid: 'a88f9c5e-2a19-4a53-99ae-605154a2eb3d',
  serviceName: 'cantrain-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cantrain-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}